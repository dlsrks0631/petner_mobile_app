package com.example.petner

data class Message(
    var message: String?, //message를 담을 변수
    var sendId: String?   //아이디를 담을 uid 변수
){
    constructor():this("","") //기본 생성자
}
