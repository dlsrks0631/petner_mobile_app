package com.example.petner

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

import androidx.recyclerview.widget.LinearLayoutManager

import com.example.petner.databinding.ActivityChatBinding

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class ChatActivity : AppCompatActivity() {

    //상대방 이름과 uid를 받는다
    private lateinit var receiverName: String
    private lateinit var receiverEmail: String

    //바인딩 객체
    private lateinit var binding: ActivityChatBinding

    lateinit var mAuth: FirebaseAuth //인증 객체
    lateinit var mDbRef: DatabaseReference//DB 객체

    private lateinit var receiverRoom: String //받는 대화방
    private lateinit var senderRoom: String //보내는 대화방

    private lateinit var messageList: ArrayList<Message>

//---------------------------------------변수 설정----------------------

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityChatBinding.inflate(layoutInflater)
        setContentView(binding.root)

        //초기화
        messageList = ArrayList()
        senderRoom = ""


        val messageAdapter: MessageAdapter = MessageAdapter(this, messageList)

        //RecyclerView
        binding.chatRecyclerView.layoutManager = LinearLayoutManager(this)
        binding.chatRecyclerView.adapter = messageAdapter

        //UserAdapter로 부터 넘어온 데이터 변수에 담기
        //activity간 변수 교환 getStringExtra는 전달되 ㄴ값을 저장
        receiverName = intent.getStringExtra("name").toString()
        receiverEmail = intent.getStringExtra("email").toString()

        mAuth = FirebaseAuth.getInstance()
        mDbRef = FirebaseDatabase.getInstance().reference

        //접속자 Uid
        val senderUid = mAuth.currentUser?.uid.toString()

        // Realtime Database에서 현재 사용자의 이메일 가져오기
        mDbRef.child(senderUid).addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {
                val currentUseremail = dataSnapshot.child("email").getValue(String::class.java)
                // email 변수에 현재 사용자의 이메일이 저장

                //val senderUid = mAuth.currentUser?.uid

                //보낸이방   String + uid
                senderRoom = receiverEmail + senderUid //보낸이방 값은 반는사람 uid + 보낸 사람 uid
                //받는이방  String + uid
                receiverRoom = senderUid + receiverEmail //받는이방 값은 보낸이 uid + 받는이 uid로 이루어 진다

                // 이 시점에서 senderRoom이 초기화된 후에 메시지를 가져오는 등의 로직을 추가할 수 있습니다.
                // 예: 메시지를 가져오는 코드 등
                binding.sendBtn.setOnClickListener {
                    val message = binding.messageEdit.text.toString()
                    val messageObject = Message(message, senderUid)

                    mDbRef.child("chats").child(senderRoom).child("messages").push()
                        .setValue(messageObject).addOnSuccessListener {
                            mDbRef.child("chats").child(receiverRoom).child("messages").push()
                                .setValue(messageObject)
                        }

                    binding.messageEdit.setText("")
                }

                // 대화방 정보를 설정한 후 메시지를 가져오는 로직도 여기에 추가
                mDbRef.child("chats").child(senderRoom).child("messages")
                    .addValueEventListener(object : ValueEventListener {
                        override fun onDataChange(snapshot: DataSnapshot) {
                            messageList.clear()
                            for (postSnapshot in snapshot.children) {
                                val message = postSnapshot.getValue(Message::class.java)
                                messageList.add(message!!)
                            }
                            messageAdapter.notifyDataSetChanged()
                        }

                        override fun onCancelled(error: DatabaseError) {
                            // 에러 처리
                        }
                    })
            }

            override fun onCancelled(databaseError: DatabaseError) {
                // 이메일 가져오기 실패 시 처리할 작업
            }
        })
        //액션바에 상대방 이름 보여주기
        supportActionBar?.title = receiverName
    }
}